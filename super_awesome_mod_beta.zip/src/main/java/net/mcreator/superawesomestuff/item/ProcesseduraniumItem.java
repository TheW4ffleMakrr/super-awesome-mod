
package net.mcreator.superawesomestuff.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;

public class ProcesseduraniumItem extends Item {
	public ProcesseduraniumItem() {
		super(new Item.Properties().tab(CreativeModeTab.TAB_MISC).durability(90).fireResistant().rarity(Rarity.EPIC));
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 0;
	}
}
