
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.superawesomestuff.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.superawesomestuff.item.UraniumItem;
import net.mcreator.superawesomestuff.item.ProcesseduraniumItem;
import net.mcreator.superawesomestuff.item.NucleardrillItem;
import net.mcreator.superawesomestuff.item.InfiniteDiamondsItem;
import net.mcreator.superawesomestuff.item.FranciumItem;
import net.mcreator.superawesomestuff.SuperAwesomeStuffMod;

public class SuperAwesomeStuffModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, SuperAwesomeStuffMod.MODID);
	public static final RegistryObject<Item> NUCLEARDRILL = REGISTRY.register("nucleardrill", () -> new NucleardrillItem());
	public static final RegistryObject<Item> FRANCIUM = REGISTRY.register("francium", () -> new FranciumItem());
	public static final RegistryObject<Item> FRANCIUMORE = block(SuperAwesomeStuffModBlocks.FRANCIUMORE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> INFINITE_DIAMONDS = REGISTRY.register("infinite_diamonds", () -> new InfiniteDiamondsItem());
	public static final RegistryObject<Item> URANIUM = REGISTRY.register("uranium", () -> new UraniumItem());
	public static final RegistryObject<Item> PROCESSEDURANIUM = REGISTRY.register("processeduranium", () -> new ProcesseduraniumItem());
	public static final RegistryObject<Item> NUKE = block(SuperAwesomeStuffModBlocks.NUKE, CreativeModeTab.TAB_BUILDING_BLOCKS);

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
