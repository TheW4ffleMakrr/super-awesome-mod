
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.superawesomestuff.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.superawesomestuff.block.NukeBlock;
import net.mcreator.superawesomestuff.block.InfiniteDiamondsPortalBlock;
import net.mcreator.superawesomestuff.block.FranciumoreBlock;
import net.mcreator.superawesomestuff.SuperAwesomeStuffMod;

public class SuperAwesomeStuffModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, SuperAwesomeStuffMod.MODID);
	public static final RegistryObject<Block> FRANCIUMORE = REGISTRY.register("franciumore", () -> new FranciumoreBlock());
	public static final RegistryObject<Block> INFINITE_DIAMONDS_PORTAL = REGISTRY.register("infinite_diamonds_portal",
			() -> new InfiniteDiamondsPortalBlock());
	public static final RegistryObject<Block> NUKE = REGISTRY.register("nuke", () -> new NukeBlock());
}
